// Primaries District Page

import React from "react";
import PrimariesElectionContainer from "../../components/primaries/PrimariesElectionContainer";

const National = () => {
  return <PrimariesElectionContainer level="NATIONAL" />;
};

export default National;
