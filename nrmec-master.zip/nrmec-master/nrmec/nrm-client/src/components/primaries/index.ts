// Export primaries components
export { default as GenericPrimariesTable } from './GenericPrimariesTable';
export { default as PrimariesElectionContainer } from './PrimariesElectionContainer';
