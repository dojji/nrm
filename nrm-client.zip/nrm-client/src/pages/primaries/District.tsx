// Primaries District Page

import React from "react";
import PrimariesElectionContainer from "../../components/primaries/PrimariesElectionContainer";

const District = () => {
  return <PrimariesElectionContainer level="DISTRICT" />;
};

export default District;
