Pending issues



************************************
Primaries

- The add candidate button is at the very end of the table
- Primaries-> when creating a candidate, the errors such as Position i missing or Input a uganda number are shown below the candidate creation modal - they need to pop up - also the success message needs to pop up.

- Primaries - Gender field is not showing 
- Primaries - When editing an exisitng candidate, the Gender, Subcategory and position are not filled by default
![alt text](image-1.png)


- Primaries - The position filter is not working with the available position from the table but instead is using the positions from the config file which can cause issues if these memebers do not exist on the table.

- Primaries -When a candidate is created the ADMIN filter units do not refreshautomatically


***********************************************************
Internal party
- The admin unit filter is not working when we get to villages
- for some items, the position is not filled espceially when the position is lacking the category and subcategory