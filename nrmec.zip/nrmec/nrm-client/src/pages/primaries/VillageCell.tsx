// Primaries Village/Cell Page

import React from "react";
import PrimariesElectionContainer from "../../components/primaries/PrimariesElectionContainer";

const VillageCell = () => {
  return <PrimariesElectionContainer level="VILLAGE_CELL" />;
};

export default VillageCell;
