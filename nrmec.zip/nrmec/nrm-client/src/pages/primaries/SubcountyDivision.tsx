// Primaries Subcounty/Division Page

import React from "react";
import PrimariesElectionContainer from "../../components/primaries/PrimariesElectionContainer";

const SubcountyDivision = () => {
  return <PrimariesElectionContainer level="SUBCOUNTY_DIVISION" />;
};

export default SubcountyDivision;
