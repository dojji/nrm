import React from "react";
import CandidateReport from "../components/CandidateReport";

const CandidateReportPage = () => {
  return (
    <div className="p-6">
      <CandidateReport />
    </div>
  );
};

export default CandidateReportPage;
